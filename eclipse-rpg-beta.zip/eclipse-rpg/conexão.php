<?php
// Alias com acento solicitado. O código utiliza conexao.php por compatibilidade.
require_once __DIR__ . '/conexao.php';
