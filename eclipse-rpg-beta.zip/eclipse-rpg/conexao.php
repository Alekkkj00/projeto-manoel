<?php
declare(strict_types=1);
/** Preencha SOMENTE .env (copie .env.example). Este arquivo nunca imprime segredos. */
function eclipse_config(): array {
    static $config;
    if ($config !== null) return $config;
    $values = [];
    $envFile = __DIR__ . '/.env';
    if (is_file($envFile)) {
        foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
            [$key, $value] = explode('=', $line, 2);
            $values[trim($key)] = trim(trim($value), "\"'");
        }
    }
    $get = static fn(string $k, string $default = ''): string => (getenv($k) !== false ? (string)getenv($k) : ($values[$k] ?? $default));
    return $config = [
        'driver' => $get('DB_DRIVER', 'local'),
        'host' => $get('DB_HOST'), 'port' => $get('DB_PORT', '5432'),
        'database' => $get('DB_NAME', 'postgres'), 'user' => $get('DB_USER'),
        'password' => $get('DB_PASSWORD'), 'sslmode' => 'require',
        'demo' => $get('DEMO_ACCOUNT', 'true') === 'true',
        'data_dir' => $get('ECLIPSE_DATA_DIR') ?: sys_get_temp_dir() . '/eclipse-beta-' . substr(hash('sha256', __DIR__), 0, 12),
    ];
}
function conexao(): ?PDO {
    $c = eclipse_config();
    if ($c['driver'] === 'local') return null;
    if ($c['driver'] !== 'pgsql') throw new RuntimeException('DB_DRIVER deve ser local ou pgsql.');
    if (!extension_loaded('pdo_pgsql')) throw new RuntimeException('Habilite pdo_pgsql no php.ini.');
    foreach (['host', 'user', 'password'] as $key) if ($c[$key] === '') throw new RuntimeException('Preencha a conexão no arquivo .env.');
    foreach (['host','port','database'] as $key) if (!preg_match('/^[a-zA-Z0-9._-]+$/', $c[$key])) throw new RuntimeException('Configuração de conexão inválida.');
    // Supabase: use os campos exatos de Connect > Session pooler (IPv4), porta 5432.
    return new PDO("pgsql:host={$c['host']};port={$c['port']};dbname={$c['database']};sslmode=require", $c['user'], $c['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}
