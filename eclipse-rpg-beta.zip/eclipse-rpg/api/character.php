<?php
require_once dirname(__DIR__) . '/app/bootstrap.php';
require_once dirname(__DIR__) . '/app/World.php';
$owner=require_user(); $b=body();
$out=(new Store())->transaction(static function(Store $s) use($owner,$b): array {
    $characters=array_values(array_filter($s->all('characters'),static fn(array $c):bool=>$c['owner']===$owner));
    $action=$b['action']??'list';
    if($action==='list') return ['characters'=>array_map(static fn(array $c):array=>array_intersect_key($c,array_flip(['id','name','class','level','map','skin','hair','savedAt'])), $characters), 'classes'=>World::CLASSES];
    if($action==='create') {
        if(count($characters)>=3) return ['error'=>'Você já tem 3 personagens.'];
        $name=trim((string)($b['name']??''));$class=(string)($b['class']??'');
        if(!preg_match('/^[\p{L}\p{N} _-]{2,20}$/u',$name) || !isset(World::CLASSES[$class])) return ['error'=>'Escolha uma classe e um nome de 2 a 20 caracteres.'];
        $skin=in_array($b['skin']??'', ['#edc5a0','#bd8964','#795240'],true)?$b['skin']:'#edc5a0';
        $hair=in_array($b['hair']??'', ['#392b36','#cfad6c','#c7d1d9'],true)?$b['hair']:'#392b36';
        $c=World::character($owner,$name,$class,$skin,$hair);$s->put('characters',$c['id'],$c);$_SESSION['character']=$c['id']; return ['ok'=>true];
    }
    if($action==='select') {
        foreach($characters as $c) if($c['id']===($b['id']??'')) {$_SESSION['character']=$c['id'];return ['ok'=>true];}
        return ['error'=>'Personagem não encontrado.'];
    }
    return ['error'=>'Ação inválida.'];
});
respond($out,isset($out['error'])?422:200);
