<?php
require_once dirname(__DIR__) . '/app/bootstrap.php';
require_once dirname(__DIR__) . '/app/Game.php';
$owner=require_user();$b=body(); $id=(string)($_SESSION['character']??'');
$out=(new Store())->transaction(static function(Store $s) use($owner,$b,$id):array {
    $p=$s->get('characters',$id);
    if(!$p || $p['owner']!==$owner) return ['error'=>'Selecione seu personagem.'];
    $game=new Game();
    if(($b['op']??'')==='load') {$p['lastTick']=microtime(true);$s->put('characters',$id,$p);return $game->snapshot($p);}
    if(($b['op']??'')!=='tick') return ['error'=>'Operação inválida.'];
    $elapsed=microtime(true)-$p['lastTick'];
    if($elapsed<.07) return $game->snapshot($p);
    // Somente comandos. HP, dano, ouro, XP e loot nunca vêm do navegador.
    $input=is_array($b['input']??null)?$b['input']:[];
    foreach(['x','y','aimX','aimY'] as $key) if(isset($input[$key]) && (!is_numeric($input[$key]) || !is_finite((float)$input[$key]))) return ['error'=>'Entrada inválida.'];
    $result=$game->tick($p,$input);$s->put('characters',$id,$p);return $result;
});
respond($out,isset($out['error'])?422:200);
