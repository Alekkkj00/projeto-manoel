<?php
require_once dirname(__DIR__) . '/app/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] === 'GET') respond(['csrf' => $_SESSION['csrf'], 'user' => $_SESSION['user'] ?? null, 'demo' => eclipse_config()['driver'] === 'local' && eclipse_config()['demo']]);
$b = body();
$action = $b['action'] ?? '';
if ($action === 'logout') {
    $_SESSION = []; session_regenerate_id(true); $_SESSION['csrf'] = bin2hex(random_bytes(32));
    respond(['ok' => true]);
}
if (!in_array($action, ['login', 'register'], true)) respond(['error' => 'Ação inválida.'], 400);
$name = strtolower(trim((string)($b['username'] ?? ''))); $pass = (string)($b['password'] ?? '');
if (!preg_match('/^[a-z0-9_]{3,24}$/', $name) || strlen($pass) > 128) respond(['error' => 'Use de 3 a 24 letras, números ou _ no usuário.'], 422);
$result = (new Store())->transaction(static function(Store $s) use ($name, $pass, $action): array {
    $key = hash('sha256', 'auth:' . ($_SERVER['REMOTE_ADDR'] ?? 'local'));
    $rate = $s->get('limits', $key) ?? ['time' => time(), 'count' => 0];
    if (time() - $rate['time'] > 600) $rate = ['time' => time(), 'count' => 0];
    if ($rate['count'] >= 12) return ['error' => 'Muitas tentativas. Aguarde 10 minutos.', 'status' => 429];
    $rate['count']++; $s->put('limits', $key, $rate);
    $config = eclipse_config();
    if ($config['driver'] === 'local' && $config['demo'] && !$s->get('users', 'create')) {
        $s->put('users', 'create', ['username' => 'create', 'hash' => password_hash('create', PASSWORD_DEFAULT), 'created' => time()]);
    }
    $user = $s->get('users', $name);
    if ($action === 'register') {
        if (strlen($pass) < 8) return ['error' => 'A nova senha precisa ter pelo menos 8 caracteres.', 'status' => 422];
        if ($user || $name === 'create') return ['error' => 'Esse usuário não está disponível.', 'status' => 409];
        $user = ['username' => $name, 'hash' => password_hash($pass, PASSWORD_DEFAULT), 'created' => time()];
        $s->put('users', $name, $user);
    } elseif (!$user || !password_verify($pass, $user['hash'])) {
        return ['error' => 'Usuário ou senha incorretos.', 'status' => 401];
    }
    // Contabiliza também sucessos para impedir automação de cadastros por IP.
    return ['ok' => true];
});
if (isset($result['error'])) respond(['error' => $result['error']], $result['status']);
session_regenerate_id(true); $_SESSION['user'] = $name; unset($_SESSION['character']);
respond(['ok' => true, 'redirect' => 'character-select.php']);
