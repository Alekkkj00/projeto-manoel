-- ECLIPSE beta 0.1 • PostgreSQL / Supabase • executar uma vez no SQL Editor.
-- Apenas o backend PHP acessa este schema. Não adicionar aos schemas da Data API.
BEGIN;
CREATE SCHEMA IF NOT EXISTS eclipse_private;
REVOKE ALL ON SCHEMA eclipse_private FROM PUBLIC, anon, authenticated;
CREATE TABLE IF NOT EXISTS eclipse_private.users (
    id text PRIMARY KEY,
    data jsonb NOT NULL CHECK (jsonb_typeof(data) = 'object'),
    updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS eclipse_private.characters (
    id text PRIMARY KEY,
    data jsonb NOT NULL CHECK (jsonb_typeof(data) = 'object'),
    updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS characters_owner_idx ON eclipse_private.characters ((data->>'owner'));
CREATE TABLE IF NOT EXISTS eclipse_private.limits (
    id text PRIMARY KEY,
    data jsonb NOT NULL CHECK (jsonb_typeof(data) = 'object'),
    updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE eclipse_private.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE eclipse_private.characters ENABLE ROW LEVEL SECURITY;
ALTER TABLE eclipse_private.limits ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON ALL TABLES IN SCHEMA eclipse_private FROM PUBLIC, anon, authenticated;
-- Sem políticas públicas: acesso de cliente negado. Use conexão de servidor
-- autorizada no .env. Autenticação desta beta é PHP, não Supabase Auth.
COMMIT;
