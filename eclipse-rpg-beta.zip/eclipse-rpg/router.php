<?php
// Servidor de desenvolvimento: php -S 127.0.0.1:8000 router.php
$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/');
if (preg_match('~(?:^|/)(?:\.|app(?:/|$)|database(?:/|$)|docs(?:/|$)|tests(?:/|$)|storage(?:/|$)|config(?:/|$))~', $path)
    || str_contains($path, '..') || preg_match('/\.(sql|md|log|py|sh)$/i', $path)) {
    http_response_code(403); exit('Acesso negado.');
}
return false;
