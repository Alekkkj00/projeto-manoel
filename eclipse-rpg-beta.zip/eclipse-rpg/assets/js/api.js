export class API {
  constructor(){this.csrf=document.querySelector('meta[name="csrf-token"]').content;}
  async call(endpoint,data){
    let response;
    try {response=await fetch(`api/${endpoint}.php`,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':this.csrf},body:JSON.stringify(data)});}
    catch{throw new Error('Sem conexão com o servidor. Verifique se o PHP está rodando.');}
    let result;try{result=await response.json();}catch{throw new Error('O servidor não respondeu em JSON. Confira o log do PHP.');}
    if(response.status===401){location.href='login.php';throw new Error('Entre novamente.');}
    if(!response.ok||result.error)throw new Error(result.error||'Não foi possível concluir.');
    return result;
  }
}
export const escapeHTML=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const classes={warrior:{name:'Guerreiro',icon:'⚔',color:'#e4ad62',skill:'Fúria circular'},mage:{name:'Mago',icon:'✧',color:'#b49aff',skill:'Nova de gelo'},archer:{name:'Arqueiro',icon:'➶',color:'#7ed8ac',skill:'Flecha dupla'},rogue:{name:'Assassino',icon:'⚡',color:'#ee8fbe',skill:'Lâmina venenosa'}};
export function toast(message){const box=document.querySelector('#toast');box.textContent=message;box.style.display='block';clearTimeout(box.timer);box.timer=setTimeout(()=>box.style.display='none',4000);}
