import {API,classes,escapeHTML as esc,toast} from './api.js';
const api=new API();
for(const close of document.querySelectorAll('[data-close]')) close.addEventListener('click',()=>close.closest('dialog').close());
for(const button of document.querySelectorAll('.logout')) button.addEventListener('click',async()=>{try{await api.call('auth',{action:'logout'});location.href='index.php';}catch(e){toast(e.message);}});
const page=document.body.dataset.page;
if(page==='home') document.querySelector('#credits').onclick=()=>document.querySelector('#credits-dialog').showModal();
if(page==='login'){
  let mode='login'; const form=document.querySelector('#auth-form'),error=document.querySelector('#form-error');
  function setMode(value){mode=value;document.querySelector('#login-tab').classList.toggle('active',mode==='login');document.querySelector('#register-tab').classList.toggle('active',mode==='register');document.querySelector('#auth-submit').textContent=mode==='login'?'Entrar no reino →':'Criar conta e entrar →';form.password.autocomplete=mode==='login'?'current-password':'new-password';form.password.minLength=mode==='register'?8:1;error.textContent='';}
  document.querySelector('#login-tab').onclick=()=>setMode('login');document.querySelector('#register-tab').onclick=()=>setMode('register');
  if(new URLSearchParams(location.search).get('mode')==='register')setMode('register');
  document.querySelector('#demo-fill')?.addEventListener('click',()=>{setMode('login');form.username.value='create';form.password.value='create';form.querySelector('button[type=submit]').focus();});
  form.onsubmit=async event=>{event.preventDefault();const button=form.querySelector('button[type=submit]');button.disabled=true;error.textContent='';try{await api.call('auth',{action:mode,username:form.username.value,password:form.password.value});location.href='character-select.php';}catch(e){error.textContent=e.message;button.disabled=false;}};
}
if(page==='characters'){
  let selected='warrior',stats={};const dialog=document.querySelector('#create-dialog');
  function choose(id){selected=id;for(const b of document.querySelectorAll('.class-option')){b.classList.toggle('selected',b.dataset.class===id);b.setAttribute('aria-pressed',String(b.dataset.class===id));}const s=stats[id];document.querySelector('#class-stats').textContent=`Vida ${s.hp} · Mana ${s.mp} · Poder ${s.power} · ${s.skill}`;}
  async function load(){try{
    const data=await api.call('character',{action:'list'});stats=data.classes;
    const root=document.querySelector('#character-list');root.replaceChildren();
    for(const c of data.characters){const card=document.createElement('article');card.className='character-card';const cl=classes[c.class];card.innerHTML=`<span class="eyebrow">NÍVEL ${c.level} · ${esc(cl.name)}</span><div class="avatar">${cl.icon}</div><h3>${esc(c.name)}</h3><p>${esc(({village:'Vila de Eldoria',forest:'Floresta dos Sussurros',cave:'Caverna dos Esquecidos'})[c.map])}</p><button class="button gold">Continuar aventura →</button>`;card.querySelector('.avatar').style.color=cl.color;card.querySelector('button').onclick=async event=>{event.target.disabled=true;try{await api.call('character',{action:'select',id:c.id});location.href='game.php';}catch(e){toast(e.message);event.target.disabled=false;}};root.append(card);}
    if(data.characters.length<3){const add=document.createElement('button');add.className='character-card empty';add.innerHTML='<span class="plus">＋</span><b>Novo personagem</b><span>Um novo destino começa aqui</span>';add.onclick=()=>dialog.showModal();root.append(add);}
    document.querySelector('#class-options').innerHTML=Object.entries(classes).map(([id,c])=>`<button type="button" class="class-option" data-class="${id}"><strong>${c.icon}</strong>${c.name}</button>`).join('');
    for(const b of document.querySelectorAll('.class-option'))b.onclick=()=>choose(b.dataset.class);choose('warrior');
  }catch(e){document.querySelector('#character-list').textContent=e.message;}}
  document.querySelector('#create-form').onsubmit=async event=>{event.preventDefault();const f=event.target,b=f.querySelector('button[type=submit]');b.disabled=true;document.querySelector('#create-error').textContent='';try{await api.call('character',{action:'create',name:f.elements.name.value,class:selected,skin:f.skin.value,hair:f.hair.value});location.href='game.php';}catch(e){document.querySelector('#create-error').textContent=e.message;b.disabled=false;}};
  load();
}
if(page==='game'){const {GameClient}=await import('./game.js');const game=new GameClient(api);await game.start();}
