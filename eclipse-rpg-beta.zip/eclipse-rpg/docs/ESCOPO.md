# Escopo real da beta 0.1

## Implementado

- Tela inicial, login/logout e cadastro; conta local create/create.
- Até três personagens por usuário; quatro classes com atributos, cores, habilidade própria e escolhas de pele/cabelo visíveis no sprite.
- Mundo 2D em Canvas; três mapas, colisões, portais condicionados a missões, minimapa, câmera, zoom e efeitos procedurais.
- WASD/setas, corrida com stamina, esquiva com invulnerabilidade breve, ataque básico dirigido pelo mouse e habilidade especial.
- Cinco tipos de adversários: slime, lobo, goblin, esqueleto e Sentinela; perseguição, alcance, retorno à origem, respawn e chefe em duas fases com ataque telegrafado.
- Dano, crítico, congelamento e veneno; mana, cooldown, defesa, XP, aumento automático de atributos e limite nível 10.
- Duas missões principais encadeadas e uma coleta secundária; duas escolhas narrativas para o encerramento do capítulo.
- Inventário compacto de arma, poções, ervas, minério, ouro e cristal. Melhoria da arma até +3, cura, compra e fabricação de poções.
- Morte, retorno à vila e penalidade moderada; salvamento do chefe e da escolha final.
- Pausa, volume, música sintetizada opcional, efeitos, zoom, redução de efeitos, tela cheia e preferências no navegador.
- Regras e recompensas no servidor; a API aceita comandos, nunca atributos/valores de recompensa. Colisões e velocidade também são verificadas no servidor. CSRF, hash de senha, sessão regenerada no login, autorização por proprietário, limite por IP no login/cadastro e transações/locks.
- Persistência local em arquivo com escrita atômica; adaptador PostgreSQL/PDO e SQL privado preparados para Supabase.

## Fora desta entrega

- Mundo completo de dez regiões, sete cristais e sete chefes, Malachar e três finais de campanha.
- 20 tipos de inimigos, 80 itens e 50 missões; esta beta tem 5 tipos, inventário enxuto e 3 missões.
- Árvore de talentos, pontos distribuíveis, seis habilidades por classe e cinco slots rápidos de habilidade.
- Arrastar/soltar, equipamentos variados, raridades, venda, descarte e comparação de equipamentos.
- Recuperação de senha por e-mail, Supabase Auth, OAuth, multiplayer e serviços de e-mail.
- Animações artísticas definitivas, spritesheets externos, música gravada, grande variedade de estados de IA e todos os efeitos de status do prompt.
- Esquema normalizado de 30 tabelas, migração automática do armazenamento local, uso concorrente em escala e hospedagem pública.
- O mapa não permite teleporte por menu. Diálogos aparecem integralmente; a introdução tem transição visual simples.
- Compatibilidade com teclado/mouse priorizada; não há direcional virtual para jogar só pelo celular.

## Próximas etapas sugeridas

1. Conectar e validar seu projeto Supabase com os campos do `.env` e SQL incluído.
2. Expandir mapas e conteúdo usando World.php e os módulos atuais.
3. Substituir persistência compacta por tabelas de domínio e locks por personagem.
4. Adicionar Supabase Auth/recuperação de senha se desejado e revisar autorização para esse novo fluxo.
5. Preparar hospedagem, HTTPS, papel de banco com privilégio mínimo e limites globais antes de lançamento público.
