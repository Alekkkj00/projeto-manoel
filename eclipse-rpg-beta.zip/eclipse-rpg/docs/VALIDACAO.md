# Validação da entrega — beta 0.1

Verificação em 26/10/2026.

## Executado e aprovado

- Sintaxe dos 16 arquivos PHP com PHP 8.3.6.
- Sintaxe dos cinco módulos JavaScript com Node.js.
- **59 verificações de regras** por `php tests/rules.php`: classes, movimento, limite de tempo, colisões, esquiva, portais, missões, consumíveis, economia, combate, alcance, cooldown, congelamento, veneno, loot, XP, chefe, escolha final e morte. Inclui pontos de acesso a objetos e posição inicial dos nove inimigos.
- **24 verificações HTTP** por `python tests/integration.py`: cadastro, sessão, CSRF, limite de personagens, acesso entre contas, login/logout, persistência e rejeição de valores de recompensa enviados pelo cliente.
- **14 verificações adicionais de interface em DOM simulado e Canvas nativo**: HUD coerente, introdução, inventário, diário, mapa, pausa, três diálogos, envio de comandos com sessão e CSRF, floresta, caverna e tela de derrota.
- Renderização dos três mapas em Canvas a 1440 × 900, com inspeção das imagens geradas.
- Salvamentos e credenciais de teste ficam fora da pasta entregue.

## Limites da validação

A inicialização do Chrome automatizado foi bloqueada pelas restrições de sockets do ambiente. Por isso, **não houve teste de ponta a ponta nem inspeção do layout CSS em um navegador real**. Os testes DOM/Canvas verificam lógica e desenho, mas não substituem essa etapa no seu computador. O checklist manual está em `CHECKLIST.md`.

A conexão ao seu Supabase **não foi executada**: os dados do seu projeto ainda serão inseridos por você. O arquivo SQL e o adaptador PDO estão incluídos para essa próxima configuração. Apache/XAMPP no Windows e os arquivos de inicialização precisam ser confirmados no seu computador; a API foi executada com o servidor embutido do PHP no Linux.

A beta é o primeiro capítulo descrito em `ESCOPO.md`. Não representa a implementação de todos os sistemas e conteúdos do prompt mestre.
