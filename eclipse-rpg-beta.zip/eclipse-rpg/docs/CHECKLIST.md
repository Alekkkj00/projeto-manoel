# Verificação manual

- [ ] Abrir a tela inicial; entrar com create/create.
- [ ] Cadastrar uma conta e verificar login/logout.
- [ ] Criar personagens com classes, pele e cabelo diferentes; limite de três.
- [ ] Conversar com Theron e aceitar a missão.
- [ ] Andar, correr e esquivar; não atravessar paredes ou casas.
- [ ] Testar ataque básico e habilidade; mana e recarga corretas.
- [ ] Coletar ervas e abrir baú uma vez; verificar mochila.
- [ ] Matar quatro criaturas; voltar ao mentor e receber recompensa uma vez.
- [ ] Verificar cura gratuita, compra de poção e fabricação com Elara.
- [ ] Melhorar arma com Borin; não gastar recursos inexistentes.
- [ ] Entrar na caverna; observar telegrafia e fase abaixo de 50% de vida.
- [ ] Vencer o chefe; recarregar e verificar que ele não reaparece.
- [ ] Entregar cristal, escolher destino e verificar decisão após novo login.
- [ ] Morrer; retornar à vila mantendo missões e itens.
- [ ] Abrir menus e verificar pausa; ajustar zoom, áudio e tela cheia.
- [ ] Parar servidor e verificar mensagem de conexão; reiniciar e reconectar.
- [ ] Recarregar e verificar posição, atributos e recompensas.
- [ ] Configurar Supabase; verificar cadastro/criação/salvamento com o próprio banco.

Testes automatizados: `php tests/rules.php` e `python tests/integration.py URL`.
Resultados desta entrega: veja `docs/VALIDACAO.md`.
