@echo off
cd /d "%~dp0"
where php >nul 2>nul
if %errorlevel% equ 0 (
  set "ECLIPSE_PHP=php"
) else (
  if exist "C:\xampp\php\php.exe" (
    set "ECLIPSE_PHP=C:\xampp\php\php.exe"
  ) else (
    echo PHP nao encontrado. Instale XAMPP ou PHP 8.2+.
    echo Depois, abra README.md para as instrucoes.
    pause
    exit /b 1
  )
)
echo.
echo ECLIPSE beta - http://127.0.0.1:8000
echo Usuario: create / Senha: create
echo Mantenha esta janela aberta. Ctrl+C para parar.
start "" "http://127.0.0.1:8000"
"%ECLIPSE_PHP%" -S 127.0.0.1:8000 router.php
pause
