# ECLIPSE — Crônicas do Reino Perdido

**Beta 0.1 jogável • PHP 8.2+ • HTML/CSS • JavaScript / Canvas • Português**

Explore Eldoria, ajude seus habitantes, derrote as criaturas da floresta e recupere o primeiro cristal na Caverna dos Esquecidos. Esta entrega é um primeiro capítulo funcional do projeto, não a campanha completa do prompt original.

## Abrir no VS Code e jogar

1. Extraia o ZIP. A pasta do projeto se chama `eclipse-rpg`.
2. No VS Code: **Arquivo → Abrir Pasta → eclipse-rpg**.
3. Instale PHP 8.2 ou superior (o PHP do XAMPP também serve).
4. No Windows, dê dois cliques em **iniciar-windows.bat**. Ele procura o PHP no PATH e em `C:\xampp\php\php.exe`.
5. Ou, no terminal do VS Code, dentro da pasta do projeto, execute:

```sh
php -S 127.0.0.1:8000 router.php
```

6. Abra **http://127.0.0.1:8000**. Faça login com:

```text
Usuário: create
Senha: create
```

7. Crie um personagem e comece. Até três personagens por conta. Também é possível cadastrar outras contas com senhas de oito ou mais caracteres.

Não é necessário configurar banco, Composer ou Node.js para testar. Não abra `index.php` com duplo clique e não use o Live Server: arquivos PHP precisam do servidor PHP. O servidor precisa permanecer aberto durante a partida. O arquivo `router.php` protege arquivos internos no servidor de desenvolvimento.

### Usar Apache / XAMPP

Alternativa ao servidor acima: coloque `eclipse-rpg` em `C:\xampp\htdocs`, inicie **Apache** e acesse **http://localhost/eclipse-rpg/**. Mantenha os arquivos `.htaccess`. Não é necessário iniciar MySQL. Se o nome da pasta mudar, as regras internas continuam protegendo os diretórios; o `.htaccess` raiz inclui também a regra para o nome padrão.

## Controles

| Tecla | Ação |
| --- | --- |
| WASD ou setas | Movimentar |
| Shift | Correr, gastando stamina |
| Espaço + direção | Esquivar |
| Clique esquerdo no mundo | Atacar na direção do mouse |
| 1 | Habilidade da classe, 18 mana / 4 s de recarga |
| E | Conversar, coletar, abrir baú, atravessar portal |
| Q | Usar poção: até 65 vida e 35 mana |
| I / C / K | Mochila, atributos e habilidade da classe |
| J | Diário de missões |
| M | Regiões e caminhos |
| Esc | Pausar / configurações |

O alvo precisa estar ao alcance e à frente do ataque básico. Os inimigos também precisam estar no alcance da habilidade especial. Os menus pausam a simulação; o backend só avança enquanto recebe comandos. Prioridade de uso: computador com teclado e mouse.

## Roteiro da beta

1. Fale com **Theron**, a noroeste da praça, e aceite a missão.
2. Siga a trilha para a direita da vila; perto do portal, pressione E.
3. Derrote quatro criaturas na floresta e volte a Theron para receber a recompensa.
4. Agora a caverna, na saída leste da floresta, pode ser acessada.
5. Enfrente a **Sentinela do Cristal**. Ao ver o círculo vermelho, saia da área ou esquive. Ela fica mais rápida abaixo de metade da vida.
6. Retorne a Theron, entregue a missão e converse novamente para escolher o destino do cristal.
7. Elara oferece cura gratuita, uma missão de ervas, venda e fabricação de poções. Borin melhora a arma usando ouro e minérios. Baús ajudam a obter recursos.

Ervas e baús são coletados uma única vez por personagem. Criaturas comuns reaparecem após 40 segundos de simulação ativa ou quando a região é recarregada. O chefe e suas recompensas não reaparecem depois da vitória. O limite desta beta é nível 10; armas podem chegar a +3.

## Salvamento local

O servidor salva posição, vida, mana, XP, ouro, mochila, missões, inimigos, chefe e escolha final. Fechar o navegador não depende de `localStorage`: somente as configurações visuais/áudio ficam no navegador.

No modo local, os saves ficam em uma pasta privada do diretório temporário do sistema, com nome derivado da localização do projeto. A limpeza do temporário pode apagá-los, e mover o projeto altera a pasta padrão. Para guardar a partida de forma durável, copie `.env.example` para `.env` e defina um diretório privado e fixo **fora de htdocs**:

```dotenv
DB_DRIVER=local
DEMO_ACCOUNT=true
ECLIPSE_DATA_DIR=C:/eclipse-dados
```

No Linux: por exemplo, `/home/SEU_USUARIO/eclipse-dados`. O processo PHP precisa ter permissão de escrita. Faça backup dessa pasta com o servidor parado. Não envie os saves ao GitHub.

## Conectar ao seu Supabase depois

O Supabase usa **PostgreSQL**, portanto o SQL incluído substitui o MySQL do prompt original.

A beta já inclui um adaptador PHP/PDO opcional. O login continua sendo **autenticação PHP com sessões e password_hash**, sem integração com Supabase Auth. Não precisa de `anon key`, publishable key nem `service_role`. O navegador nunca recebe a senha do banco.

1. No Supabase, abra seu projeto e execute `database/supabase.sql` no **SQL Editor**. Faça isso somente no projeto de banco escolhido para o jogo.
2. Em **Connect → Session pooler**, copie host, porta, database e usuário exatos. O usuário do pooler costuma ser diferente do usuário da conexão direta. Session pooler é a opção adequada para redes locais IPv4 e prepared statements.
3. Habilite `pdo_pgsql` no seu `php.ini` e reinicie o PHP/Apache. No XAMPP, procure a linha `;extension=pdo_pgsql` e remova o `;`.
4. Copie `.env.example` para `.env` e preencha:

```dotenv
DB_DRIVER=pgsql
DEMO_ACCOUNT=false
DB_HOST=COLE_O_HOST_DO_SESSION_POOLER
DB_PORT=5432
DB_NAME=postgres
DB_USER=COLE_O_USUARIO_DO_SESSION_POOLER
DB_PASSWORD=COLE_A_SENHA_DO_BANCO
```

5. `conexao.php` lê esses campos e abre a conexão PDO com SSL obrigatório. `conexão.php` também existe como alias com acento. Se preferir, você pode editar os valores padrão em `conexao.php`, mas **não coloque senhas nesse arquivo se pretende versioná-lo**.
6. Reinicie o servidor, saia da conta local e cadastre uma conta no modo PostgreSQL. O acesso `create/create` só é criado automaticamente no modo local. A troca de modo não migra os saves; cada armazenamento é independente.

O SQL usa um schema privado chamado `eclipse_private`, com três tabelas: `users`, `characters` e `limits`. Os dados variáveis do jogo ficam em JSONB nesta fase. RLS está habilitado e clientes `anon`/`authenticated` não têm acesso. Não exponha esse schema na Data API. A conexão PHP deve usar um papel de servidor autorizado, normalmente o proprietário das tabelas criado via SQL Editor; não use essa credencial em JS.

Este é um esqueleto de persistência para uma beta pequena: há um lock global para evitar concorrência e duplicação. A normalização completa e locks por personagem ficam para uma etapa de escala. Nenhuma conexão foi feita ao seu banco nesta entrega; a integração remota precisa ser verificada depois que você preencher as credenciais.

Referência oficial de conexão: https://supabase.com/docs/guides/database/connecting-to-postgres

## Subir ao GitHub por sua conta

A pasta já contém `.gitignore`. Credenciais `.env`, logs e diretórios comuns de armazenamento ficam ignorados. O pacote não contém credenciais reais nem partidas de teste.

No terminal do VS Code, depois de criar um repositório vazio no seu GitHub:

```sh
git init
git add .
git status
# Confira a lista acima antes do commit: .env e saves não devem aparecer.
git commit -m "Adiciona beta inicial do Eclipse RPG"
git branch -M main
git remote add origin URL_DO_SEU_REPOSITORIO
git push -u origin main
```

**GitHub Pages não executa PHP.** O repositório pode guardar o código, mas jogar online exige uma hospedagem com PHP 8.2+ e conexão ao banco. Não publique a conta de teste numa instalação aberta à internet.

## Organização

```text
eclipse-rpg/
  index.php, login.php, register.php, character-select.php, game.php
  conexao.php, conexão.php, router.php
  app/             # Store, regras do mundo, combate, sessões e layout
  api/             # autenticação, personagens e comandos do jogo
  assets/css/      # interface
  assets/js/       # API, menus, renderer, áudio e loop
  database/        # SQL do Supabase / PostgreSQL
  docs/            # escopo e checklist
  tests/           # testes de regras e integração
  .vscode/         # tarefa para iniciar o servidor e extensão sugerida
  .env.example, .gitignore, iniciar-windows.bat
```

## Testes e problemas comuns

Execute `php tests/rules.php` para verificar regras, colisões, recompensas, missões, morte e combate. Com o servidor rodando, `python tests/integration.py http://127.0.0.1:8000` verifica API, sessões, acesso entre contas e persistência; ele cria contas próprias de teste.

- **PHP não reconhecido:** use `C:\xampp\php\php.exe -S 127.0.0.1:8000 router.php`, ou execute o `.bat`.
- **Porta ocupada:** troque `8000` por `8001` no comando e no navegador.
- **Sessão expirada:** recarregue a página e entre novamente. Verifique se cookies estão habilitados.
- **Muitas tentativas:** aguarde 10 minutos; o limite é por IP e inclui cadastro.
- **Erro de salvamento:** verifique permissão na pasta de dados e no diretório temporário de sessões do PHP. No modo Supabase, verifique extensão PDO, senha, host, usuário e SQL inicial. As mensagens técnicas ficam no log do PHP.
- **Áudio não inicia:** clique no mundo ou pressione uma tecla; o navegador exige interação antes de permitir som.
- **Arquivos internos acessíveis com Apache:** confira se `AllowOverride` permite os `.htaccess` e se os módulos de autorização estão habilitados. Para outro servidor (Nginx/IIS), configure regras equivalentes antes de publicar.

Leia `docs/ESCOPO.md` para o que esta versão inclui e o que ainda está planejado.
