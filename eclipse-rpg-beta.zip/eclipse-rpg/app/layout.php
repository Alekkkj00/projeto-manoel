<?php
require_once __DIR__ . '/bootstrap.php';
function page_start(string $title,string $page):void { ?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="csrf-token" content="<?=e($_SESSION['csrf'])?>"><meta name="account" content="<?=e($_SESSION['user']??'')?>"><meta name="theme-color" content="#0b111b"><title><?=e($title)?> · ECLIPSE</title><link rel="icon" href="assets/icons.svg" type="image/svg+xml"><link rel="stylesheet" href="assets/css/style.css"></head><body data-page="<?=e($page)?>"><?php }
function brand():void { ?><a class="brand" href="index.php"><span class="brand-mark"></span><span>ECLIPSE<small>CRÔNICAS DO REINO PERDIDO</small></span></a><?php }
function page_end():void { ?><div id="toast" role="status" aria-live="polite"></div><script type="module" src="assets/js/app.js"></script></body></html><?php }
