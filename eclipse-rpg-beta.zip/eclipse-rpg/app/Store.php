<?php
declare(strict_types=1);
/** Repositório beta: arquivo JSON com flock, ou PostgreSQL/JSONB privado.
 * Toda chamada deve estar dentro de transaction(). Bloqueio global deliberado
 * nesta beta pequena; para escalar, substituir por locks por conta/personagem.
 */
final class Store {
    private ?PDO $pdo;
    private array $data = [];
    private const BUCKETS = ['users', 'characters', 'limits'];
    public function __construct() { $this->pdo = conexao(); }
    public function transaction(callable $fn): mixed {
        if ($this->pdo) {
            $this->pdo->beginTransaction();
            try {
                $this->pdo->exec('SELECT pg_advisory_xact_lock(19850730)');
                $out = $fn($this);
                $this->pdo->commit(); return $out;
            } catch (Throwable $e) { if ($this->pdo->inTransaction()) $this->pdo->rollBack(); throw $e; }
        }
        $dir = eclipse_config()['data_dir'];
        if ($dir === '') throw new RuntimeException('ECLIPSE_DATA_DIR não pode ficar vazio se definido.');
        if (!is_dir($dir) && !mkdir($dir, 0700, true) && !is_dir($dir)) throw new RuntimeException('Sem permissão para criar pasta de saves.');
        $lock = fopen($dir . '/store.lock', 'c');
        if (!$lock || !flock($lock, LOCK_EX)) throw new RuntimeException('Não foi possível bloquear o salvamento.');
        try {
            $path = $dir . '/store.json';
            $this->data = is_file($path) ? json_decode((string)file_get_contents($path), true, 512, JSON_THROW_ON_ERROR) : array_fill_keys(self::BUCKETS, []);
            $out = $fn($this);
            $tmp = tempnam($dir, 'save-');
            try {
                if (file_put_contents($tmp, json_encode($this->data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE)) === false || !rename($tmp, $path)) throw new RuntimeException('Falha ao salvar.');
                chmod($path, 0600);
            } finally { if (is_file($tmp)) unlink($tmp); }
            return $out;
        } finally { flock($lock, LOCK_UN); fclose($lock); }
    }
    private function table(string $bucket): string {
        if (!in_array($bucket, self::BUCKETS, true)) throw new InvalidArgumentException('Repositório inválido.');
        return 'eclipse_private.' . $bucket;
    }
    public function get(string $bucket, string $key): ?array {
        $table = $this->table($bucket);
        if (!$this->pdo) return $this->data[$bucket][$key] ?? null;
        $stmt = $this->pdo->prepare("SELECT data FROM $table WHERE id = :id"); $stmt->execute(['id' => $key]);
        $data = $stmt->fetchColumn(); return $data === false ? null : json_decode($data, true, 512, JSON_THROW_ON_ERROR);
    }
    public function all(string $bucket): array {
        $table = $this->table($bucket);
        if (!$this->pdo) return array_values($this->data[$bucket]);
        return array_map(static fn(array $r): array => json_decode($r['data'], true, 512, JSON_THROW_ON_ERROR), $this->pdo->query("SELECT data FROM $table")->fetchAll());
    }
    public function put(string $bucket, string $key, array $data): void {
        $table = $this->table($bucket);
        if (!$this->pdo) { $this->data[$bucket][$key] = $data; return; }
        $stmt = $this->pdo->prepare("INSERT INTO $table (id, data) VALUES (:id, CAST(:data AS jsonb)) ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, updated_at = now()");
        $stmt->execute(['id' => $key, 'data' => json_encode($data, JSON_THROW_ON_ERROR)]);
    }
}
