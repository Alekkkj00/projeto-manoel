<?php
declare(strict_types=1);
final class World {
    public const W = 1280; public const H = 896;
    public const CLASSES = [
        'warrior' => ['name' => 'Guerreiro', 'hp' => 150, 'mp' => 40, 'power' => 20, 'defense' => 8, 'range' => 86, 'color' => '#e4ad62', 'skill' => 'Fúria circular'],
        'mage' => ['name' => 'Mago', 'hp' => 80, 'mp' => 160, 'power' => 24, 'defense' => 3, 'range' => 280, 'color' => '#b49aff', 'skill' => 'Nova de gelo'],
        'archer' => ['name' => 'Arqueiro', 'hp' => 100, 'mp' => 80, 'power' => 19, 'defense' => 5, 'range' => 320, 'color' => '#7ed8ac', 'skill' => 'Flecha dupla'],
        'rogue' => ['name' => 'Assassino', 'hp' => 95, 'mp' => 90, 'power' => 22, 'defense' => 4, 'range' => 92, 'color' => '#ee8fbe', 'skill' => 'Lâmina venenosa'],
    ];
    public static function map(string $id): array {
        $base = ['id' => $id, 'width' => self::W, 'height' => self::H, 'obstacles' => [], 'npcs' => [], 'portals' => [], 'nodes' => []];
        if ($id === 'village') {
            $base['name'] = 'Vila de Eldoria'; $base['subtitle'] = 'O último refúgio da luz';
            $base['obstacles'] = [
                ['x'=>128,'y'=>128,'w'=>192,'h'=>136,'type'=>'house'], ['x'=>400,'y'=>128,'w'=>168,'h'=>112,'type'=>'house'],
                ['x'=>640,'y'=>120,'w'=>192,'h'=>128,'type'=>'forge'], ['x'=>928,'y'=>176,'w'=>152,'h'=>120,'type'=>'house'],
                ['x'=>192,'y'=>624,'w'=>176,'h'=>128,'type'=>'house'], ['x'=>760,'y'=>650,'w'=>192,'h'=>112,'type'=>'house'],
                ['x'=>590,'y'=>440,'w'=>72,'h'=>64,'type'=>'well'],
            ];
            $base['npcs'] = [['id'=>'theron','name'=>'Ancião Theron','x'=>240,'y'=>344], ['id'=>'elara','name'=>'Elara · curandeira','x'=>464,'y'=>310], ['id'=>'borin','name'=>'Borin · ferreiro','x'=>736,'y'=>312]];
            $base['portals'] = [['x'=>1200,'y'=>448,'to'=>'forest','label'=>'Floresta →']];
        } elseif ($id === 'forest') {
            $base['name'] = 'Floresta dos Sussurros'; $base['subtitle'] = 'Há algo entre as árvores';
            for ($i=0;$i<27;$i++) {
                $x = 150 + (($i * 173) % 1000); $y = 85 + (($i * 227) % 720);
                if (abs($y-448) < 90 || ($x>1060 && $y>300 && $y<600)) continue;
                $base['obstacles'][] = ['x'=>$x,'y'=>$y,'w'=>54,'h'=>48,'type'=>'tree'];
            }
            $base['portals'] = [['x'=>64,'y'=>448,'to'=>'village','label'=>'← Eldoria'], ['x'=>1200,'y'=>448,'to'=>'cave','label'=>'Caverna →']];
            foreach ([[260,610],[420,240],[680,640],[850,270],[1030,600]] as $i=>$p) $base['nodes'][] = ['id'=>'herb'.$i,'type'=>'herb','x'=>$p[0],'y'=>$p[1]];
            $base['nodes'][] = ['id'=>'forest_chest','type'=>'chest','x'=>1090,'y'=>190];
        } else {
            $base['name'] = 'Caverna dos Esquecidos'; $base['subtitle'] = 'O primeiro cristal aguarda';
            foreach ([[300,200],[300,600],[650,150],[650,690],[1000,220],[1000,620]] as $p) $base['obstacles'][] = ['x'=>$p[0],'y'=>$p[1],'w'=>72,'h'=>70,'type'=>'rock'];
            $base['portals'] = [['x'=>64,'y'=>448,'to'=>'forest','label'=>'← Floresta']];
            $base['nodes'] = [['id'=>'cave_chest','type'=>'chest','x'=>1140,'y'=>720]];
        }
        return $base;
    }
    public static function canMove(string $map, float $x, float $y, float $r=13): bool {
        if ($x < 30 || $y < 45 || $x > self::W-30 || $y > self::H-35) return false;
        foreach (self::map($map)['obstacles'] as $o) if ($x+$r>$o['x'] && $x-$r<$o['x']+$o['w'] && $y+$r>$o['y'] && $y-$r<$o['y']+$o['h']) return false;
        return true;
    }
    public static function enemies(string $map): array {
        $spots = $map === 'forest' ? [[340,440,'slime'],[500,520,'slime'],[620,380,'wolf'],[820,440,'goblin'],[1020,510,'wolf'],[920,710,'goblin']] : ($map === 'cave' ? [[330,440,'skeleton'],[560,440,'skeleton'],[800,440,'boss']] : []);
        $enemies=[];
        foreach ($spots as $i=>$p) {
            $boss = $p[2]==='boss';
            $hp = $boss ? 360 : match($p[2]) {'slime'=>48,'wolf'=>65,'goblin'=>75,default=>90};
            $enemies[] = ['id'=>$map.'_'.$i, 'kind'=>$p[2], 'name'=>match($p[2]) {'slime'=>'Slime sombrio','wolf'=>'Lobo corrompido','goblin'=>'Goblin saqueador','skeleton'=>'Esqueleto perdido',default=>'Sentinela do Cristal'}, 'x'=>$p[0], 'y'=>$p[1], 'homeX'=>$p[0], 'homeY'=>$p[1], 'hp'=>$hp, 'maxHp'=>$hp, 'attackAt'=>0, 'respawnAt'=>0, 'frozenUntil'=>0, 'poisonUntil'=>0, 'poisonAt'=>0, 'windup'=>0, 'blastAt'=>0];
        }
        return $enemies;
    }
    public static function character(string $owner, string $name, string $class, string $skin, string $hair): array {
        $c = self::CLASSES[$class];
        return ['id'=>bin2hex(random_bytes(12)), 'owner'=>$owner, 'name'=>$name, 'class'=>$class, 'skin'=>$skin, 'hair'=>$hair, 'level'=>1, 'xp'=>0, 'hp'=>$c['hp'], 'mp'=>$c['mp'], 'stamina'=>100, 'gold'=>25, 'potions'=>4, 'herbs'=>0, 'ore'=>0, 'weapon'=>0, 'map'=>'village', 'x'=>360, 'y'=>440, 'quest'=>0, 'kills'=>0, 'herbQuest'=>0, 'crystal'=>false, 'bossDefeated'=>false, 'ending'=>null, 'collected'=>[], 'enemies'=>[], 'attackAt'=>0, 'skillAt'=>0, 'dodgeAt'=>0, 'invulnerable'=>0, 'lastTick'=>microtime(true), 'savedAt'=>time()];
    }
    public static function stats(array $p): array {
        $c=self::CLASSES[$p['class']]; $l=$p['level']-1;
        return ['maxHp'=>$c['hp']+$l*14, 'maxMp'=>$c['mp']+$l*8, 'power'=>$c['power']+$l*4+$p['weapon']*6, 'defense'=>$c['defense']+$l*2, 'range'=>$c['range'], 'nextXp'=>(int)round(100*$p['level']**1.5)];
    }
}
