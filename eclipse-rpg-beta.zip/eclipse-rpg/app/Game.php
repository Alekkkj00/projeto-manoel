<?php
declare(strict_types=1);
require_once __DIR__ . '/World.php';
final class Game {
    private array $events=[];
    private function say(string $text, string $type='info', ?float $x=null, ?float $y=null): void { $this->events[]=['text'=>$text,'type'=>$type,'x'=>$x,'y'=>$y]; }
    private function dist(array $a,array $b): float { return hypot($a['x']-$b['x'],$a['y']-$b['y']); }
    private function move(array &$entity, string $map, float $dx, float $dy): void {
        if(World::canMove($map,$entity['x']+$dx,$entity['y'])) $entity['x']+=$dx;
        if(World::canMove($map,$entity['x'],$entity['y']+$dy)) $entity['y']+=$dy;
    }
    public function snapshot(array $p): array {
        unset($p['owner']);
        return ['player'=>$p,'stats'=>World::stats($p),'world'=>World::map($p['map']),'events'=>$this->events,'serverTime'=>microtime(true)];
    }
    private function xp(array &$p,int $amount): void {
        $p['xp']+=$amount;
        while($p['level']<10 && $p['xp']>=World::stats($p)['nextXp']) {
            $p['xp']-=World::stats($p)['nextXp']; $p['level']++;
            $stats=World::stats($p); $p['hp']=$stats['maxHp']; $p['mp']=$stats['maxMp'];
            $this->say('Nível '.$p['level'].'! Seus atributos aumentaram.','level');
        }
    }
    private function killed(array &$p,array &$e,float $now): void {
        if($e['hp']>0 || $e['respawnAt']>0) return;
        $boss=$e['kind']==='boss'; $e['respawnAt']=$boss ? PHP_INT_MAX : $now+40;
        $p['gold']+=$boss ? 100 : random_int(6,12); $p['ore']+=random_int(0,1);
        $this->xp($p,$boss?180:30); $p['kills']++;
        if($boss) { $p['crystal']=true; $p['bossDefeated']=true; $this->say('O cristal despertou. Retorne a Theron.','quest'); }
        else $this->say('+30 XP · ouro recebido','loot',$e['x'],$e['y']);
    }
    public function tick(array &$p,array $in): array {
        $now=microtime(true); $dt=max(0,min(.25,$now-$p['lastTick'])); $p['lastTick']=$now;
        if ($p['hp']<=0) {
            if(($in['action']??'')==='revive') {
                $p['gold']=max(0,$p['gold']-10); $p['map']='village'; $p['x']=360; $p['y']=440;
                $p['hp']=World::stats($p)['maxHp']; $p['mp']=World::stats($p)['maxMp']; $p['enemies']=[];
                $this->say('Elara trouxe você de volta. −10 ouro, quando disponível.');
            }
            return $this->snapshot($p);
        }
        $stats=World::stats($p); $map=$p['map'];
        $p['mp']=min($stats['maxMp'],$p['mp']+$dt*2.5);
        $dx=max(-1,min(1,(float)($in['x']??0))); $dy=max(-1,min(1,(float)($in['y']??0))); $len=hypot($dx,$dy);
        if($len>0) {$dx/=$len; $dy/=$len;}
        $run=!empty($in['run']) && $p['stamina']>5 && $len>0;
        $speed=$run?230:150;
        $p['stamina']=max(0,min(100,$p['stamina']+($run?-25:22)*$dt));
        $this->move($p,$map,$dx*$speed*$dt,$dy*$speed*$dt);
        if(!empty($in['dodge']) && $len>0 && $p['stamina']>=25 && $now>=$p['dodgeAt']) {
            // Pequenos passos: a esquiva não atravessa paredes.
            for($i=0;$i<8;$i++) $this->move($p,$map,$dx*10,$dy*10);
            $p['stamina']-=25; $p['dodgeAt']=$now+1.5; $p['invulnerable']=$now+.45;
            $this->say('Esquiva','dodge',$p['x'],$p['y']);
        }
        if(!$p['enemies']) $p['enemies']=World::enemies($map);
        if(!empty($in['attack']) && $now >= $p['attackAt']) {
            $p['attackAt']=$now+.48; $this->attack($p,$in,$now,false);
        }
        if(!empty($in['special']) && $now >= $p['skillAt']) {
            if($p['mp']>=18) { $p['mp']-=18; $p['skillAt']=$now+4; $this->attack($p,$in,$now,true); }
            else $this->say('Mana insuficiente.');
        }
        foreach($p['enemies'] as &$enemy) {
            if($enemy['hp']<=0) {
                if($now>=$enemy['respawnAt']) {$enemy['hp']=$enemy['maxHp'];$enemy['x']=$enemy['homeX'];$enemy['y']=$enemy['homeY'];$enemy['respawnAt']=0;$enemy['poisonUntil']=0;$enemy['windup']=0;}
                continue;
            }
            if($enemy['poisonUntil']>$now && $now>=$enemy['poisonAt']) {
                $enemy['hp']=max(0,$enemy['hp']-8); $enemy['poisonAt']=$now+1; $this->say('8','damage',$enemy['x'],$enemy['y']);
                $this->killed($p,$enemy,$now); if($enemy['hp']<=0) continue;
            }
            $d=$this->dist($p,$enemy); $boss=$enemy['kind']==='boss';
            if($enemy['windup']>0) {
                if($now>=$enemy['windup']) {
                    if($d<150 && $now>$p['invulnerable']) {$p['hp']=max(0,$p['hp']-24);$this->say('−24','hurt',$p['x'],$p['y']);}
                    $enemy['windup']=0; $enemy['blastAt']=$now+5;
                    $this->say('Onda do vazio','blast',$enemy['x'],$enemy['y']);
                }
                continue;
            }
            if($enemy['frozenUntil']>$now) continue;
            if($boss && $d<235 && $now>=$enemy['blastAt']) { $enemy['windup']=$now+.9; continue; }
            $phase=$boss && $enemy['hp']<$enemy['maxHp']/2;
            if($d<($boss?450:250)) {
                if($d>34) $this->move($enemy,$map,($p['x']-$enemy['x'])/max(1,$d)*($phase?105:($boss?62:77))*$dt,($p['y']-$enemy['y'])/max(1,$d)*($phase?105:($boss?62:77))*$dt);
                if($d<45 && $now>=$enemy['attackAt']) {
                    $enemy['attackAt']=$now+($phase?.7:1.1);
                    if($now>$p['invulnerable']) {
                        $damage=max(2,($boss?20:11)-$stats['defense']); $p['hp']=max(0,$p['hp']-$damage);
                        $this->say('−'.$damage,'hurt',$p['x'],$p['y']);
                    }
                }
            } else {
                $back=hypot($enemy['homeX']-$enemy['x'],$enemy['homeY']-$enemy['y']);
                if($back>6) $this->move($enemy,$map,($enemy['homeX']-$enemy['x'])/$back*60*$dt,($enemy['homeY']-$enemy['y'])/$back*60*$dt);
            }
        }
        unset($enemy);
        if($p['hp']>0) $this->action($p,(string)($in['action']??''),$now);
        $p['savedAt']=time();
        return $this->snapshot($p);
    }
    private function attack(array &$p,array $in,float $now,bool $special): void {
        $stats=World::stats($p); $range=$special && in_array($p['class'],['warrior','mage'],true)?165:$stats['range'];
        $ax=(float)($in['aimX']??$p['x']+1)-$p['x']; $ay=(float)($in['aimY']??$p['y'])-$p['y']; $al=max(1,hypot($ax,$ay));
        $this->events[]=['type'=>'attack','text'=>$special?'skill':'basic','x'=>$p['x'],'y'=>$p['y'],'aimX'=>$p['x']+$ax/$al*$range,'aimY'=>$p['y']+$ay/$al*$range,'class'=>$p['class']];
        foreach($p['enemies'] as &$e) {
            $d=$this->dist($p,$e); $dot=(($e['x']-$p['x'])*$ax+($e['y']-$p['y'])*$ay)/($al*max(1,$d));
            if($e['hp']<=0 || $d>$range || (!$special && $dot<.25)) continue;
            $critical=random_int(1,100)<=($p['class']==='rogue'?25:10);
            $damage=(int)round($stats['power']*($special?1.9:1)*($critical?1.6:1));
            $e['hp']=max(0,$e['hp']-$damage);
            if($special && $p['class']==='mage') $e['frozenUntil']=$now+2;
            if($special && $p['class']==='rogue') {$e['poisonUntil']=$now+4;$e['poisonAt']=$now+1;}
            $this->say((string)$damage.($critical?'!':''),'damage',$e['x'],$e['y']);
            $this->killed($p,$e,$now);
            if(!$special || in_array($p['class'],['archer','rogue'],true)) break;
        }
        unset($e);
    }
    private function nearbyNpc(array $p,string $id): bool {
        foreach(World::map($p['map'])['npcs'] as $n) if($n['id']===$id && $this->dist($p,$n)<95) return true;
        return false;
    }
    private function action(array &$p,string $action,float $now): void {
        if($action==='potion') {
            if($p['potions']<1) {$this->say('Você não tem poções.'); return;}
            $stats=World::stats($p);
            if($p['hp']>=$stats['maxHp'] && $p['mp']>=$stats['maxMp']) return;
            $p['potions']--; $p['hp']=min($stats['maxHp'],$p['hp']+65); $p['mp']=min($stats['maxMp'],$p['mp']+35);
            $this->say('Poção: +65 vida / +35 mana','heal'); return;
        }
        if($action==='accept' && $this->nearbyNpc($p,'theron') && $p['quest']===0) {$p['quest']=1;$this->say('Missão aceita. Derrote 4 criaturas na floresta.','quest');}
        if($action==='turnin' && $this->nearbyNpc($p,'theron')) {
            if($p['quest']===1 && $p['kills']>=4) {$p['quest']=2;$p['gold']+=50;$this->xp($p,100);$this->say('Caverna liberada! +50 ouro e +100 XP.','quest');}
            elseif($p['quest']===2 && $p['crystal']) {$p['quest']=3;$p['gold']+=120;$this->xp($p,200);$this->say('O futuro do cristal está em suas mãos.','quest');}
        }
        if(in_array($action,['protect','study'],true) && $this->nearbyNpc($p,'theron') && $p['quest']===3 && !$p['ending']) {
            $p['ending']=$action; $p['quest']=4; $this->say($action==='protect'?'O cristal protege Eldoria. Você se tornou seu guardião.':'O cristal revela um caminho para Arkanis. A aventura continuará.','victory');
        }
        if($action==='herbs' && $this->nearbyNpc($p,'elara')) {
            if($p['herbQuest']===0) {$p['herbQuest']=1;$this->say('Elara precisa de 3 ervas luminosas.','quest');}
            elseif($p['herbQuest']===1 && $p['herbs']>=3) {$p['herbs']-=3;$p['herbQuest']=2;$p['potions']+=3;$this->xp($p,60);$this->say('Ervas entregues! +3 poções e +60 XP.','quest');}
        }
        if($this->nearbyNpc($p,'elara')) {
            if($action==='rest') {$s=World::stats($p);$p['hp']=$s['maxHp'];$p['mp']=$s['maxMp'];$this->say('Elara restaurou sua vida e mana.','heal');}
            if($action==='buy') {if($p['gold']>=15){$p['gold']-=15;$p['potions']++;$this->say('Poção comprada. −15 ouro.');}else $this->say('Ouro insuficiente.');}
            if($action==='craft') {if($p['herbs']>=2){$p['herbs']-=2;$p['potions']++;$this->say('Poção fabricada. −2 ervas.');}else $this->say('Você precisa de 2 ervas.');}
        }
        if($action==='upgrade' && $this->nearbyNpc($p,'borin')) {
            if($p['weapon']>=3) $this->say('Arma no nível máximo desta beta.');
            elseif($p['gold']>=60 && $p['ore']>=2) {$p['gold']-=60;$p['ore']-=2;$p['weapon']++;$this->say('Arma +'.$p['weapon'].'! +6 de poder.','loot');}
            else $this->say('Borin precisa de 60 ouro e 2 minérios.');
        }
        if($action!=='interact') return;
        $world=World::map($p['map']);
        foreach($world['npcs'] as $n) if($this->dist($p,$n)<85) {$this->events[]=['type'=>'dialogue','npc'=>$n['id'],'text'=>$n['name']];return;}
        foreach($world['nodes'] as $node) if($this->dist($p,$node)<65 && !in_array($node['id'],$p['collected'],true)) {
            $p['collected'][]=$node['id'];
            if($node['type']==='herb') {$p['herbs']++;$this->say('+1 erva luminosa','loot');}
            else {$p['gold']+=30;$p['ore']+=2;$this->say('Baú: +30 ouro, +2 minérios','loot');}
            return;
        }
        foreach($world['portals'] as $portal) if($this->dist($p,$portal)<75) {
            if($portal['to']==='forest' && $p['quest']===0) {$this->say('Fale com Theron antes de sair da vila.'); return;}
            if($portal['to']==='cave' && $p['quest']<2) {$this->say('Conclua a primeira missão e volte a Theron.'); return;}
            $from=$p['map']; $p['map']=$portal['to']; $p['x']=($from==='cave' || $p['map']==='village')?1110:155; $p['y']=448;
            $p['enemies']=World::enemies($p['map']);
            if($p['bossDefeated']) foreach($p['enemies'] as &$e) if($e['kind']==='boss') {$e['hp']=0;$e['respawnAt']=PHP_INT_MAX;}
            unset($e);$p['invulnerable']=$now+2;
            $this->say(World::map($p['map'])['name'],'region');return;
        }
        $this->say('Aproxime-se de uma pessoa, erva, baú ou portal.');
    }
}
