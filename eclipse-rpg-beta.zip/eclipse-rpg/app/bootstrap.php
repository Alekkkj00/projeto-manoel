<?php
declare(strict_types=1);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
require_once dirname(__DIR__) . '/conexao.php';
require_once __DIR__ . '/Store.php';
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
header('Referrer-Policy: same-origin');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; media-src 'self' blob:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
ini_set('session.use_strict_mode', '1');
session_name('eclipse_beta');
session_set_cookie_params(['httponly' => true, 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'samesite' => 'Lax', 'path' => '/']);
session_start();
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
function respond(array $data, int $code = 200): never {
    http_response_code($code); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR); exit;
}
function body(): array {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond(['error' => 'Use POST.'], 405);
    if (!hash_equals($_SESSION['csrf'], (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''))) respond(['error' => 'Sessão expirada. Recarregue a página.'], 403);
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 8192) respond(['error' => 'Pedido muito grande.'], 413);
    try { $body = json_decode(file_get_contents('php://input'), true, 32, JSON_THROW_ON_ERROR); }
    catch (JsonException) { respond(['error' => 'JSON inválido.'], 400); }
    if (!is_array($body)) respond(['error' => 'Pedido inválido.'], 400);
    return $body;
}
function require_user(): string {
    if (empty($_SESSION['user'])) respond(['error' => 'Entre novamente.'], 401);
    return $_SESSION['user'];
}
function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
set_exception_handler(static function(Throwable $ex): void {
    error_log('[Eclipse] ' . $ex->getMessage());
    if (str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/')) respond(['error' => 'Não foi possível concluir. Confira a configuração e o log do PHP.'], 500);
    http_response_code(500); echo 'Não foi possível abrir o jogo. Confira a configuração e o log do PHP.';
});
