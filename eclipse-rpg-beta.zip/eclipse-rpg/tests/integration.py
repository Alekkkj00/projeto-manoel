#!/usr/bin/env python3
"""Teste da API com contas novas. Usa só biblioteca padrão do Python 3."""
import json, sys, time, uuid
from urllib.request import build_opener, HTTPCookieProcessor, Request
from urllib.error import HTTPError
from http.cookiejar import CookieJar
BASE=(sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8000').rstrip('/')
checks=0

def check(value, text):
    global checks
    assert value, text
    checks+=1
    print('✓', text)

class Client:
    def __init__(self):
        self.http=build_opener(HTTPCookieProcessor(CookieJar()))
        self.csrf=self.get('/api/auth.php')[1]['csrf']
    def get(self,path):
        try:
            with self.http.open(BASE+path) as r:
                raw=r.read();return r.status,json.loads(raw) if r.headers.get_content_type()=='application/json' else raw.decode()
        except HTTPError as e:return e.code,e.read().decode()
    def call(self,endpoint,data,csrf=True):
        headers={'Content-Type':'application/json'}
        if csrf:headers['X-CSRF-Token']=self.csrf
        req=Request(BASE+'/api/'+endpoint+'.php',json.dumps(data).encode(),headers)
        try:
            with self.http.open(req) as r:return r.status,json.load(r)
        except HTTPError as e:return e.code,json.load(e)

a=Client();b=Client()
check(a.call('character',{'action':'list'})[0]==401,'Personagens exigem sessão autenticada')
check(a.call('auth',{'action':'login','username':'create','password':'create'},False)[0]==403,'CSRF inválido é bloqueado')
suffix=uuid.uuid4().hex[:10]
for client,user in [(a,'testa_'+suffix),(b,'testb_'+suffix)]:
    check(client.call('auth',{'action':'register','username':user,'password':'SenhaTeste123!'})[0]==200,'Cadastro com hash de senha e sessão')
check(a.call('character',{'action':'create','name':'<script>','class':'mage'})[0]==422,'Nome com marcação é rejeitado')
for cl in ['warrior','mage','archer']:
    check(a.call('character',{'action':'create','name':'Beta '+cl,'class':cl,'skin':'#bd8964','hair':'#cfad6c'})[0]==200,'Criação de personagem '+cl)
check(a.call('character',{'action':'create','name':'Quarto','class':'rogue'})[0]==422,'Limite de três personagens')
status,data=a.call('character',{'action':'list'});char=data['characters'][0]
check(len(data['characters'])==3 and 'hash' not in json.dumps(data),'Lista sem dados de senha')
check(b.call('character',{'action':'select','id':char['id']})[0]==422,'Outra conta não pode selecionar personagem alheio')
check(a.call('character',{'action':'select','id':char['id']})[0]==200,'Selecionar personagem próprio')
status,data=a.call('game',{'op':'load'});p=data['player']
check(status==200 and 'owner' not in p,'Carregar jogo e ocultar proprietário interno')
time.sleep(.15)
status,data=a.call('game',{'op':'tick','input':{'x':1,'y':0,'gold':999999,'xp':99999,'hp':99999}})
check(status==200 and data['player']['gold']==25 and data['player']['level']==1,'API ignora recompensas e atributos enviados pelo cliente')
x=data['player']['x']
check(x>p['x'] and x-p['x']<=38,'Movimento validado e limitado no servidor')
check(a.call('game',{'op':'load'})[1]['player']['x']==x,'Posição é persistida e recarregada')
for path in ['/app/World.php','/database/supabase.sql','/.env.example','/tests/rules.php']:
    check(a.get(path)[0]==403,'Arquivo interno protegido: '+path)
check(a.call('auth',{'action':'logout'})[0]==200,'Logout')
# O token muda no logout; renová-lo antes de tentar entrar novamente.
a.csrf=a.get('/api/auth.php')[1]['csrf']
check(a.call('auth',{'action':'login','username':'testa_'+suffix,'password':'SenhaErrada'})[0]==401,'Login rejeita senha errada')
check(a.call('auth',{'action':'login','username':'testa_'+suffix,'password':'SenhaTeste123!'})[0]==200,'Login recupera conta cadastrada')
check(len(a.call('character',{'action':'list'})[1]['characters'])==3,'Personagens persistem após logout/login')
print(f'\n{checks} verificações de integração aprovadas.')
