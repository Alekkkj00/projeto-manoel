<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/app/Game.php';
$checks=0;
function check(bool $condition,string $message):void { global $checks; if(!$condition) throw new RuntimeException('FALHOU: '.$message);$checks++;echo "✓ $message\n"; }
function fresh(string $class='warrior'):array {return World::character('tester','Teste',$class,'#bd8964','#cfad6c');}
function step(array &$p,array $input=[]):array {$p['lastTick']=microtime(true)-.2;return (new Game())->tick($p,$input);}
foreach(World::CLASSES as $id=>$cl){$p=fresh($id);check($p['hp']===$cl['hp'] && World::stats($p)['power']===$cl['power'],'Atributos iniciais: '.$cl['name']);}
$p=fresh();$start=$p['x'];step($p,['x'=>1]);check($p['x']>$start && $p['x']-$start<31,'Movimento limitado pelo tempo do servidor');
$p=fresh();$p['x']=360;$p['y']=440;$p['lastTick']=microtime(true)-100;$before=$p['x'];(new Game())->tick($p,['x'=>1]);check($p['x']-$before<38,'Pausa longa não permite teletransporte');
check(!World::canMove('village',200,180),'Colisão com casa');check(!World::canMove('village',5,400),'Colisão com limite');
$p=fresh();$p['x']=360;$p['y']=440;step($p,['x'=>1,'dodge'=>true]);check($p['stamina']<=75 && $p['dodgeAt']>microtime(true),'Esquiva consome stamina e ativa cooldown');
$p=fresh();$p['x']=240;$p['y']=344;step($p,['action'=>'accept']);check($p['quest']===1,'Aceitar missão apenas perto do mentor');
$p=fresh();step($p,['action'=>'accept']);check($p['quest']===0,'Mentor não pode ser acionado de longe');
$p=fresh();$p['x']=1200;$p['y']=448;step($p,['action'=>'interact']);check($p['map']==='village','Portal inicial exige missão');$p['quest']=1;step($p,['action'=>'interact']);check($p['map']==='forest','Transição entre regiões');
$p['x']=1200;$p['y']=448;step($p,['action'=>'interact']);check($p['map']==='forest','Caverna exige conclusão da caça');
$p=fresh();$p['map']='forest';$p['x']=1090;$p['y']=190;$gold=$p['gold'];step($p,['action'=>'interact']);step($p,['action'=>'interact']);check($p['gold']===$gold+30 && $p['ore']===2,'Baú só concede recompensa uma vez');
$p=fresh();$p['map']='forest';$p['x']=600;$p['y']=440;$p['enemies']=World::enemies('forest');
foreach($p['enemies'] as &$e){$e['x']=1200;$e['y']=800;}unset($e);$p['enemies'][0]['x']=640;$p['enemies'][0]['y']=440;
$hp=$p['enemies'][0]['hp'];step($p,['attack'=>true,'aimX'=>700,'aimY'=>440]);$after=$p['enemies'][0]['hp'];check($after<$hp,'Ataque atinge alvo no alcance');
step($p,['attack'=>true,'aimX'=>700,'aimY'=>440]);check($p['enemies'][0]['hp']===$after,'Cooldown impede ataque repetido imediato');
$p['attackAt']=0;$p['enemies'][0]['x']=1000;$after=$p['enemies'][0]['hp'];step($p,['attack'=>true,'aimX'=>1000,'aimY'=>440]);check($p['enemies'][0]['hp']===$after,'Ataque não atinge fora do alcance');
$p=fresh('mage');$p['map']='forest';$p['x']=600;$p['y']=440;$p['enemies']=World::enemies('forest');$p['enemies'][0]['x']=650;$p['enemies'][0]['y']=440;step($p,['special'=>true]);check($p['mp']<160 && $p['enemies'][0]['frozenUntil']>microtime(true),'Habilidade do mago gasta mana e congela');$mana=$p['mp'];step($p,['special'=>true]);check($p['mp']>=$mana,'Recarga de habilidade bloqueia gasto duplicado');
$p=fresh('rogue');$p['map']='forest';$p['x']=600;$p['y']=440;$p['enemies']=World::enemies('forest');$p['enemies'][0]['hp']=100;$p['enemies'][0]['maxHp']=100;$p['enemies'][0]['x']=650;$p['enemies'][0]['y']=440;step($p,['special'=>true]);check($p['enemies'][0]['poisonUntil']>microtime(true),'Assassino aplica veneno');
$p=fresh();$p['map']='forest';$p['x']=600;$p['y']=440;$p['xp']=90;$p['enemies']=World::enemies('forest');$p['enemies'][0]['hp']=1;$p['enemies'][0]['x']=640;$p['enemies'][0]['y']=440;step($p,['attack'=>true,'aimX'=>700,'aimY'=>440]);check($p['level']===2 && $p['xp']===20 && $p['gold']>25,'Morte concede loot e evolução pelo servidor');
$p=fresh();$p['x']=240;$p['y']=344;$p['quest']=1;$p['kills']=4;step($p,['action'=>'turnin']);$gold=$p['gold'];step($p,['action'=>'turnin']);check($p['quest']===2 && $p['gold']===$gold && $gold===75,'Recompensa da caça não duplica');
$p=fresh();$p['hp']=10;step($p,['action'=>'potion']);check($p['potions']===3 && $p['hp']===75,'Poção restaura vida e consome item');
$p=fresh();$p['x']=464;$p['y']=310;$p['gold']=0;step($p,['action'=>'buy']);check($p['gold']===0 && $p['potions']===4,'Compra não permite saldo negativo');
$p['gold']=30;step($p,['action'=>'buy']);check($p['gold']===15 && $p['potions']===5,'Compra desconta custo do servidor');
$p['herbs']=2;step($p,['action'=>'craft']);check($p['herbs']===0 && $p['potions']===6,'Fabricação consome materiais');step($p,['action'=>'craft']);check($p['potions']===6,'Fabricação não duplica sem materiais');
$p['herbs']=3;step($p,['action'=>'herbs']);step($p,['action'=>'herbs']);check($p['herbQuest']===2 && $p['potions']===9 && $p['herbs']===0,'Missão secundária entrega ervas e recompensa');
$p=fresh();$p['x']=736;$p['y']=312;$p['gold']=100;$p['ore']=2;step($p,['action'=>'upgrade']);check($p['weapon']===1 && World::stats($p)['power']===26 && $p['gold']===40 && $p['ore']===0,'Melhoria de arma altera poder e recursos');
$p=fresh();$p['map']='cave';$p['quest']=2;$p['x']=760;$p['y']=448;$p['enemies']=World::enemies('cave');$p['enemies'][2]['hp']=1;step($p,['attack'=>true,'aimX'=>820,'aimY'=>448]);check($p['bossDefeated'] && $p['crystal'],'Chefe concede cristal e marca persistente');$gold=$p['gold'];$p['attackAt']=0;step($p,['attack'=>true,'aimX'=>820,'aimY'=>448]);check($p['gold']===$gold,'Chefe não concede recompensa em duplicidade');
$p['map']='village';$p['x']=240;$p['y']=344;$p['enemies']=[];step($p,['action'=>'turnin']);check($p['quest']===3,'Entrega do cristal avança história');step($p,['action'=>'protect']);check($p['quest']===4 && $p['ending']==='protect','Escolha narrativa persistente');step($p,['action'=>'study']);check($p['ending']==='protect','Escolha final não pode ser sobrescrita');
$p=fresh();$p['hp']=0;$p['map']='cave';$p['quest']=2;$p['gold']=3;step($p,['action'=>'revive']);check($p['map']==='village' && $p['hp']>0 && $p['gold']===0 && $p['quest']===2,'Morte e retorno preservam missão, sem saldo negativo');
foreach(['village','forest','cave'] as $map){$w=World::map($map);foreach([...$w['npcs'],...$w['nodes'],...$w['portals']] as $n){$reachable=false;for($angle=0;$angle<360;$angle+=20){$r=45;$x=$n['x']+cos(deg2rad($angle))*$r;$y=$n['y']+sin(deg2rad($angle))*$r;if(World::canMove($map,$x,$y)){$reachable=true;break;}}check($reachable,'Objeto interagível tem ponto de acesso: '.$map.' / '.($n['id']??$n['to']));}}
foreach(['forest','cave'] as $map) foreach(World::enemies($map) as $enemy) check(World::canMove($map,$enemy['x'],$enemy['y']),'Inimigo nasce fora de obstáculos: '.$enemy['id']);
echo "\n$checks verificações aprovadas.\n";
